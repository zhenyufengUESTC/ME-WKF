close all;clear all;
%%
% @ Copyright: Zhengyu Feng @ UESTC.
% @ Date: 2021.05.10.
% @ Version: V_1.0.
clear all; close all;
fprintf('Begining...\n');
run('Table_1_time_invariant_sigma_delta_5');
fprintf('Running...\n');
run('Table_1_time_invariant_sigma_delta_10');
fprintf('Running...\n');
run('Table_1_time_invariant_sigma_delta_15');
fprintf('Running...\n');
run('Table_1_time_invariant_sigma_delta_20');
fprintf('Running...\n');
run('Table_1_time_invariant_sigma_delta_25');
fprintf('Running...\n');

run('Table_2_time_varing_sigma_delta_5');
fprintf('Running...\n');
run('Table_2_time_varing_sigma_delta_10');
fprintf('Running...\n');
run('Table_2_time_varing_sigma_delta_15');
fprintf('Running...\n');
run('Table_2_time_varing_sigma_delta_20');
fprintf('Running...\n');
run('Table_2_time_varing_sigma_delta_25');
fprintf('Ending...\n');